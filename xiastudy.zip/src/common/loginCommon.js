import loginApi from "../network/login";

export function findTalk(userId) {
  this.current += 1
  loginApi.findTalk(userId, this.current, this.limit)
    .then(response => {
      this.talkList = response.data.data.talkList
    })
}
