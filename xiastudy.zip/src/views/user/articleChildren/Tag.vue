<template>
  <article-tag :label-list="this.labelList" :title-flag="true"></article-tag>
</template>

<script>
import ArticleTag from "../common/ArticleTag";
import loginApi from "../../../network/login";

export default {
  name: "Tag",
  components: {ArticleTag},
  data() {
    return {
      labelList:  [
        {
          labelName: 'a'
        },
        {
          labelName: 'b'
        },
        {
          labelName: 'c'
        },
        {
          labelName: 'd'
        },
        {
          labelName: 'e'
        },
      ]
    }
  },
  methods: {
    findUserSpan(userId) {
      loginApi.findUserSpan(userId)
        .then(response => {
          this.labelList = response.data.data.labelList
        })
    }
  },
  created() {
    this.findUserSpan(this.$store.state.loginInfo.id)
  }
}
</script>

<style scoped>

</style>
