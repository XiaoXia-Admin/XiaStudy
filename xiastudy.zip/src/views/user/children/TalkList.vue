<template>
  <talk-about :talk-list="this.talkList" :other-talk="false" :total="this.total" :current="this.current" :limit="this.limit"></talk-about>
</template>

<script>
import TalkAbout from "../common/TalkAbout";
import loginApi from "../../../network/login";
import {findTalk} from "../../../common/loginCommon";
import cookie from "js-cookie";
export default {
  name: "TalkList",
  components: {TalkAbout},
  data() {
    return {
      talkList: [
        {
          id: 1,
          content: '今天是美好的一天!',
          isPublic: 0,
          gtmCreate: '2022-01-02 13:17'
        },
        {
          id: 2,
          content: '今天是美好的二天!',
          isPublic: 1,
          gtmCreate: '2022-01-02 13:17'
        },
        {
          id: 3,
          content: '今天是美好的三天!',
          isPublic: 0,
          gtmCreate: '2022-01-02 13:17'
        },
        {
          id: 4,
          content: '今天是美好的四天!',
          isPublic: 1,
          gtmCreate: ''
        }
      ],
      current: 0,
      limit: 20,
      total: 100
    }
  },
  methods: {
    findTalk

  },
  created() {
    this.findTalk(this.$store.state.loginInfo.id)
  }
}
</script>

<style scoped>

</style>
