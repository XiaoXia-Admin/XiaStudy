<template>
  <div>
    文章详情
  </div>
</template>

<script>
export default {
  name: "CourseDetail"
}
</script>

<style scoped>

</style>
