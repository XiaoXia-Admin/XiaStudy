<template>
  <div>
    文章章节
  </div>
</template>

<script>
export default {
  name: "CourseChapter"
}
</script>

<style scoped>

</style>
