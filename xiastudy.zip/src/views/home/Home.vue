<template>
  <div id="home">
    <sec class="login"></sec>
  </div>
</template>
<script>

import Sec from "../../components/common/section/Sec";

export default {
  name: "Home",
  components: {
    Sec
  }
}
</script>

<style scoped>

</style>
