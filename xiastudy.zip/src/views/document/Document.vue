<template>
  <h1>官方文档</h1>
</template>

<script>
export default {
  name: "Document"
}
</script>

<style scoped>

</style>
