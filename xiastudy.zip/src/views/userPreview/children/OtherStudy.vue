<template>
  <div class="container">
    <div class="ksd-main-content">
      <div class="bottom_content bgfcolor" style="display: block; overflow: hidden; min-height: 680px;">
        <div class="row mx-0 ">
          <div class="col-12  content_box blog-main bg-white mb-3 pb-4 pt-3 col-md-12">
            <div>
              <div class="content person_works" id="submit-video-list">
                <ul id="ksd-course-cube-list" class="xjy-left work_lists cl">
                  <li  v-for="(item,index) in courseList" :key="item.id" :data-courseid="item.id" data-pages="2" data-total="22" class="z pos animated fadeInLeft">
                    <a target="_blank" :title="item.title" :href="'/course/detail/' + item.id" class="hide shadow_cover">
                    </a><a target="_blank" :title="item.title" :href="'/course/detail/' + item.id" class="cover">
                    <img class="imgloadinglater" onerror="imgError(this)" :src="item.cover" :alt="item.title"></a>
                    <div class="work_bt"><a target="_blank" :title="item.title" :href="'/course/detail/' + item.id" class="title">如何准备面试</a>
                      <a :href="'/course/play/' + item.id" style="font-size:12px;float:right;color: #1E9FFF;font-weight: bold;" target="_blank"><i class="iconfont icon-play"></i>进入点播</a>
                      <div class="number mt-2">
                        <span><i class="iconfont icon-icon_yulan fsi"></i>{{item.views}}</span>
                      </div>
                    </div>
                  </li>
                </ul>
                <div class="clearfix clear"></div> <!---->
                <div data-pages="2" data-total="22" data-pageno="1" class="ksd-page-loadmore ksd-page loadmore"><a
                  href="javascript:void(0);"><span class="msg">点击加载更多，共 <span class="fw">{{this.total}}/{{Math.ceil(this.total/20)}}</span>，当前: <span class="fw">{{this.page}}/2</span></span></a>
                </div> <!----></div>
            </div> <!----> <!----> <!----> <!----></div> <!----></div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: "OtherStudy",
  data() {
    return {
      total: 122,
      page: 1, //当前页面
      courseList: [
        {
          id: 1,
          title: '如何准备面试',
          cover: './static/footimg/03.jpg',
          views: 8
        },
        {
          id: 2,
          title: '如何准备面试',
          cover: './static/footimg/850301863063588864.jpg',
          views: 8
        },
        {
          id: 3,
          title: '如何准备面试',
          cover: './static/footimg/03.jpg',
          views: 8
        },
        {
          id: 4,
          title: '如何准备面试',
          cover: './static/footimg/850301863063588864.jpg',
          views: 8
        },
        {
          id: 5,
          title: '如何准备面试',
          cover: './static/footimg/03.jpg',
          views: 8
        },

      ]
    }
  }
}
</script>
<style scoped>
.section {
  position: relative;
}

#page-video #submit-video .content {
  max-height: none;
  overflow: hidden;
}

#page-video #submit-video-list {
  margin-left: -5px;
}

.person_works .work_lists, .person_works .file_lists {
  position: relative;
}

ul {
  list-style: none
}

.person_works .work_lists li {
  padding: 10px;
  width: 268px;
  height: 229px;
  margin-left: 15px;
  overflow: hidden;
  transition: all 0.3s;
  background-color: #f4f5f7;
  margin-bottom: 15px;
  float: left;
}

.animated.delay-1s {
  -webkit-animation-delay: 50ms;
  animation-delay: 50ms;
}

a {
  color: #000000;
}

.person_works .work_lists .cover {
  width: 100%;
  padding-bottom: 5px;
  display: block;
  overflow: hidden;
}

person_works .work_lists .cover img {
  width: 100%;
  -webkit-transition: all 0.3s;
  transition: all 0.3s;
}

.imgloadinglater {
  width: 240px;
  max-height: 142px;
}

.person_works .work_lists .work_bt {
  padding: 0 10px;
  box-sizing: border-box;
}

.person_works .work_lists .work_bt .title {
  display: block;
  height: 20px;
  line-height: 20px;
  font-size: 14px;
  font-weight: 500;
  color: #303133;
  margin-top: 8px;
  margin-bottom: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.person_works .work_lists .work_bt .number {
  font-size: 0;
}

.mt-2, .my-2 {
  margin-top: .5rem !important;
}

.person_works .work_lists .work_bt .number span {
  font-size: 12px;
  color: #34495e;
  display: inline-block;
  margin-right: 6px;
}

.person_works .work_lists .work_bt .number i {
  margin-right: 4px;
}

.ksd-pages-nodata, .ksd-noempty, .loadmore, .ksd-page-loadmore {
  text-align: center;
  background: #f4f5f7 !important;
  position: relative;
  z-index: 100;
  padding: 5px;
  color: #666;
  cursor: pointer;
}

.person_works .work_lists li:hover .cover img {
  -webkit-transform: scale(1.02);
  transform: scale(1.02);
}

.person_works .work_lists .cover img {
  width: 100%;
  -webkit-transition: all 0.3s;
  transition: all 0.3s;
}

.imgloadinglater {
  width: 240px;
  max-height: 142px;
}

.person_works .work_lists li:hover, .person_works .jk_lists li:hover {
  -webkit-transform: translateY(-5px);
  transform: translateY(-5px);
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
}
.fadeInLeft {
  -webkit-animation-name: fadeInLeft;
  animation-name: fadeInLeft;
}
.animated {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}
</style>
