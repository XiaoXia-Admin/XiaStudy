<template>
  <div class="main">
    <div class="layui-container" style="padding:0;">
      <preview-title :is-collection="this.isCollection" :article="this.article">
        <toc></toc>
      </preview-title>
      <markdown-to-html :id="this.id" :markdown-value="this.markdownValue"></markdown-to-html>
      <div class="xjy-left copy-text mb-4 mt-4"
           style="position: relative;z-index: 100;background-color: white;margin-left: -17px;margin-top: -26px;top: -24px;height: 57px;margin-right: 17px;">
        <span class="ksd-tagsspan">标签：<em v-show="labelList.length > 0" v-for="(item, index) in labelList"
                                          :key="item.labelName" class="ksd-topic-tags pr ftp2" :title="item.labelName">{{
            item.labelName
          }}</em></span>
      </div>
      <div class="layui-row layui-col-space15 main mt-4"
           style="margin-bottom: 100px; margin-left: -17px;margin-right: 16px;">
        <div class="layui-col-md12 layui-col-lg12" style="padding:10px 25px;">
          <div class="comment-text layui-form">
            <div id="comments">
              <div id="commentbox-post">
                <div id="respond-post" class="respond">
                  <div class="cancel-comment-reply">
                    <a id="cancel-comment-reply-link" style="display: none" href="javascript:void(0);">
                      取消回复
                    </a>
                  </div>
                  <div class="layui-form-item">
                    <div id="commentarea" class="xjy-left" style="z-index: 10;position: relative">

                    </div>
                  </div>
                  <div class="layui-inline">
                    <button id="submit-comment" @click="submitBtn" style="margin-left: 963px;"
                            class="layui-btn layui-btn-normal fr"><i
                      class="iconfont icon-tianxie pr-2"></i>提交评论
                    </button>
                  </div>
                </div>
              </div>
              <div v-show="this.reviewTotal > 0" id="commentbox" data-topicid="1363074625050828802">
                <br>
                <h3>总共已有 <span class="totalcount1">{{ reviewTotal }}</span> 条评论</h3>
                <br>
                <!--                评论-->
                <div>
                  <div class="pinglun">
                    <ol class="comment-list-ol comment-list-ol-ol">
                      <li :data-ctotal="reviewTotal" data-total="104" :data-pages="current"
                          v-for="(item, index) in commentList" :key="item.id"
                          :id="'li-comment-' + item.id"
                          class="animated fadeInUpBig comment-body comment-parent comment-odd">
                        <!--                        父评论-->
                        <div :id="'comment-' + item.id" class="pl-dan comment-txt-box">
                          <div class="t-p comment-author position-relative">
                            <a :href="'/other/user/' + item.userId" target="_blank">
                              <img class="avatar" :src="item.userAvatar" width="40" height="40"></a>
                          </div>
                          <div class="t-u comment-author">
                <span>
                    <a :href="'/other/user/' + item.userId" class="fw"
                       target="_blank"><span>{{ item.userNickname }}</span></a>
                    <span class="layui-badge"></span>
                </span>
                            <div class="pt-1">
                              <span class="t-btn">
                        <a href="javascript:void(0);"
                           :data-opid="item.userId" :data-nickname="item.userNickname"
                           :data-avatar="item.userAvatar"
                           :data-ruid="item.id" rel="nofollow" class="ksd-reply-link" @click="replayPreview($event, 1)"><i
                          class="iconfont icon-fenxiang"></i>回复</a>

                        <span class="t-g">{{ item.gmtCreate }}</span>
                    </span>
                            </div>
                            <div><b></b></div>
                            <div class="t-s"><p>{{ item.content }}<br></p></div>
                          </div>
                        </div>
                        <!--                        子评论-->
                        <div class="pl-list comment-children">
                          <ol class="comment-list" :id="'comment-list-children-' + item.userId"
                              v-for="(item1,index) in item.childList" :key="item1.id">
                            <li :id="'li-comment-' + item1.id"
                                class="comment-body comment-child comment-level-odd comment-odd comment-by-author animation4 fadeInUpBig">
                              <div :id="'comment-' + item1.id" class="pl-dan comment-txt-box">
                                <div class="t-p comment-author position-relative">
                                  <a :href="'/other/user/' + item1.userId" target="_blank"><img class="avatar"
                                                                                                :src="item1.userAvatar"
                                                                                                width="40"
                                                                                                height="40"></a>
                                </div>
                                <div class="t-u comment-author">
                                <span>
                                    <a :href="'/other/user/' + item1.userId" class="fw"
                                       target="_blank"><span>{{ item1.userNickname }}</span></a>


                                    <span class="touser_sp">@<a :href="'/other/user/' + item1.replyUserId"
                                                                target="_blank">{{ item1.replyUserNickname }}</a></span>
                                    <span class="layui-badge"></span>
                                </span>
                                  <div class="pt-1">
                                <span class="t-btn">
                                    <a href="javascript:void(0)"
                                       :data-opid="item1.userId" :data-nickname="item1.userNickname"
                                       :data-avatar="item1.userAvatar"
                                       data-ruid="e73cbe9b3c21455ca55f371cf9efd0aa" rel="nofollow"
                                       class="ksd-reply-link" @click="replayPreview($event, 2)"><i
                                      class="iconfont icon-fenxiang "></i>回复</a>
                                    <a :data-commentid="item1.id"
                                       class="ksd-comment-deletelink rpl-red" href="javascript:void(0);"
                                       @click="deletePreview"><i
                                      class="iconfont icon-chahao"></i>删除</a>
                                    <span class="t-g">{{ item1.gmtCreate }}</span>
                                </span></div>
                                  <div><b></b></div>
                                  <div class="t-s"><p>{{ item1.content }}</p></div>
                                </div>
                              </div>
                            </li>
                          </ol>

                        </div>
                      </li>
                    </ol>
                  </div>
                </div>

                <div class="loadmore" style=""><a href="javascript:void(0);"><span class="msg">加载更多评论</span>
                  (共<span class="totalcount fw">{{ reviewTotal }}</span>条 / 当前<span
                    class="fw pages">{{ this.current }}</span>页)</a></div>
              </div>
              <!--                没评论显示-->
              <div v-show="this.reviewTotal == 0" class="mt-5 mt-5 text-center ksd-empty-box-c" style="">
                <div class="ksd-noempty none" style="background: rgb(255, 255, 255) !important; display: block;">
                  <span class="font-weight-bold"><img :src="this.img" alt="" width="200"></span>
                  <p>坐等您的评论...</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="tipoff-box js-tipoff-box animated bounceInDown" :class="{show: this.accusation}">
      <div class="tipoff-top-box clearfix">
        <p class="l tipoff-title">举报</p>
        <span class="r tipoff-close-btn icon-close2 js-tipoff-close"></span>
      </div>
      <div class="tipoff-type-box js-tipoff-typebox clearfix">
        <div class="item l" title="广告或垃圾信息"><i class="l icon-weixuanze iconfont" data-type="1"></i>
          <p class="l">广告或垃圾信息</p></div>
        <div class="item l" title="辱骂"><i class="l icon-weixuanze iconfont" data-type="2"></i>
          <p class="l">辱骂</p></div>
        <div class="item l" title="涉政或违法"><i class="l icon-weixuanze iconfont" data-type="3"></i>
          <p class="l">涉政或违法</p></div>
        <div class="item l" title="抄袭"><i class="l icon-weixuanze iconfont" data-type="4"></i>
          <p class="l">抄袭</p></div>
        <div class="item l" title="不合适内容"><i class="l iconfont icon-weixuanze" data-type="5"></i>
          <p class="l">不合适内容</p></div>
      </div>
      <div class="tipoff-content">
        <textarea name="tipoff-content" id="tipoff-content" class="tipoff-desc js-tipoff-desc"
                  placeholder="写下举报理由"></textarea>
        <div class="tipoff-text"><span class="js-tipoff-text" style="color: rgb(147, 153, 159);">0</span>/150</div>
      </div>
      <div class="tipoff-btn-box clearfix">
        <div class="r tipoff-submit-btn js-tipoff-submit" @click="submitBtn">提交
        </div>
        <div class="r tipoff-cancel-btn js-tipoff-close" @click="cancelBtn">取消</div>
      </div>
    </div>
    <div class="tipoff-block js-tipoff-block" :class="{show: this.accusation}"></div>
  </div>
</template>

<script>

import EditorMarkdown from "./EditorMarkdown";
import {backToTop, createEditor, easeInOutQuad, loadToc, mkImageShow} from "../../../common/utils";
import PreviewTitle from "./PreviewTitle";
import MarkdownToHtml from "./MarkdownToHtml";
import Toc from "./Toc";
import bbsApi from "../../../network/bbs";
import loginApi from "../../../network/login";
import E from "wangeditor";

export default {
  name: "Preview",
  components: {Toc, MarkdownToHtml, PreviewTitle, EditorMarkdown},
  data() {
    return {
      editor: null,
      time: 500,
      config: {
        width: "98%",
        height: 440,
        path: "./static/lib/editormd/lib/",
        codeFold: true, // 代码折叠
        lineWrapping: true, // 编辑框不换行
        watch: true,// 实时预览
        saveHTMLToTextarea: true,    // 保存 HTML 到 Textarea
        searchReplace: true,
        htmlDecode: "style,script,iframe|on*",            // 开启 HTML 标签解析，为了安全性，默认不开启
        emoji: false,
        taskList: true,
        tocm: true,         // Using [TOCM]
        tex: true,                   // 开启科学公式TeX语言支持，默认关闭
        flowChart: true,             // 开启流程图支持，默认关闭
        sequenceDiagram: true,       // 开启时序/序列图支持，默认关闭,
        imageUpload: true,
        imageFormats: ["jpg", "jpeg", "gif", "png", "bmp", "webp"],
        imageUploadURL: "./php/upload.php",


        toolbarIcons: function () {
          return [
            "bold",
            "list-ul", "list-ol", "emoji"
          ]
        },
        toolbarIconTexts: {
          model: `<i class="fa" style="font-size: 16px;text-align: center;display: block;font-weight: bolder;padding: 5px;" name="testIcon" unselectable="on">模板</i>`,  // 如果没有图标，则可以这样直接插入内容，可以是字符串或HTML标签
          markdown: `<i class="fa" name="layoutmd" unselectable="on"><a href="https://www.kuangstudy.com/bbs/1356475333565587458" target="_blank">MarkDown指南</a></i>`
        },
        onload: function () {
        }
      },
      markdownValue: `### 主要特性


> 引用文本 Blockquotes

引用的行内混合 Blockquotes

> 引用：如果想要插入空白换行\`即<br />标签\`，在插入处先键入两个以上的空格然后回车即可，[普通链接](http://localhost/)。

### 锚点与链接 Links

[普通链接](http://localhost/)

[普通链接带标题](http://localhost/ "普通链接带标题")

直接链接：<https://github.com>

[锚点链接][anchor-id]

[anchor-id]: http://www.this-anchor-link.com/

GFM a-tail link @pandao

> @pandao

### 多语言代码高亮 Codes

#### 行内代码 Inline code

执行命令：\`npm install marked\`

#### 缩进风格

即缩进四个空格，也做为实现类似\`<pre>\`预格式化文本(Preformatted Text)的功能。

    <?php
        echo "Hello world!";
    ?>

预格式化文本：

    | First Header  | Second Header |
    | ------------- | ------------- |
    | Content Cell  | Content Cell  |
    | Content Cell  | Content Cell  |

#### JS代码　

\`\`\`javascript
function test(){
\tconsole.log("Hello world!");
}

(function(){
    let box = function(){
        return box.fn.init();
    };

    box.prototype = box.fn = {
        init : function(){
            console.log('box.init()');

\t\t\treturn this;
        },

\t\tadd : function(str){
\t\t\talert("add", str);

\t\t\treturn this;
\t\t},

\t\tremove : function(str){
\t\t\talert("remove", str);

\t\t\treturn this;
\t\t}
    };

    box.fn.init.prototype = box.fn;

    window.box =box;
})();

let testBox = box();
testBox.add("jQuery").remove("jQuery");
\`\`\`

#### HTML代码 HTML codes

\`\`\`html
<!DOCTYPE html>
<html>
    <head>
        <mate charest="utf-8" />
        <title>Hello world!</title>
    </head>
    <body>
        <h1>Hello world!</h1>
    </body>
</html>
\`\`\`

### 图片 Images

Image:

![](https://pandao.github.io/editor.md/examples/images/4.jpg)

> Follow your heart.

![](https://pandao.github.io/editor.md/examples/images/8.jpg)

> 图为：厦门白城沙滩

图片加链接 (Image + Link)：

![](https://pandao.github.io/editor.md/examples/images/7.jpg)(https://pandao.github.io/editor.md/examples/images/7.jpg "李健首张专辑《似水流年》封面")

> 图为：李健首张专辑《似水流年》封面

----

### 列表 Lists

#### 无序列表（减号）Unordered Lists (-)

- 列表一
- 列表二
- 列表三

#### 无序列表（星号）Unordered Lists (*)

* 列表一
* 列表二
* 列表三

#### 无序列表（加号和嵌套）Unordered Lists (+)

+ 列表一
+ 列表二
    + 列表二-1
    + 列表二-2
    + 列表二-3
+ 列表三
    * 列表一
    * 列表二
    * 列表三

#### 有序列表 Ordered Lists (-)

1. 第一行
2. 第二行
3. 第三行

#### GFM task list

- [x] GFM task list 1
- [x] GFM task list 2
- [ ] GFM task list 3
    - [ ] GFM task list 3-1
    - [ ] GFM task list 3-2
    - [ ] GFM task list 3-3
- [ ] GFM task list 4
    - [ ] GFM task list 4-1
    - [ ] GFM task list 4-2

----

### 绘制表格 Tables

| 项目        | 价格   |  数量  |
| --------   | -----:  | :----:  |
| 计算机      | $1600   |   5     |
| 手机        |   $12   |   12   |
| 管线        |    $1    |  234  |

First Header  | Second Header
------------- | -------------
Content Cell  | Content Cell
Content Cell  | Content Cell

| First Header  | Second Header |
| ------------- | ------------- |
| Content Cell  | Content Cell  |
| Content Cell  | Content Cell  |

| Function name | Description                    |
| ------------- | ------------------------------ |
| \`help()\`      | Display the help window.       |
| \`destroy()\`   | **Destroy your computer!**     |

| Left-Aligned  | Center Aligned  | Right Aligned |
| :------------ |:---------------:| -----:|
| col 3 is      | some wordy text | $1600 |
| col 2 is      | centered        |   $12 |
| zebra stripes | are neat        |    $1 |

| Item      | Value |
| --------- | -----:|
| Computer  | $1600 |
| Phone     |   $12 |
| Pipe      |    $1 |

----

#### 特殊符号 HTML Entities Codes

&copy; &  &uml; &trade; &iexcl; &pound;
&amp; &lt; &gt; &yen; &euro; &reg; &plusmn; &para; &sect; &brvbar; &macr; &laquo; &middot;

X&sup2; Y&sup3; &frac34; &frac14;  &times;  &divide;   &raquo;

18&ordm;C  &quot;  &apos;

### Emoji表情 :smiley:

> Blockquotes :star:

#### GFM task lists & Emoji & fontAwesome icon emoji & editormd logo emoji :editormd-logo-5x:

- [x] :smiley: @mentions, :smiley: #refs, [links](), **formatting**, and <del>tags</del> supported :editormd-logo:;
- [x] list syntax required (any unordered or ordered list supported) :editormd-logo-3x:;
- [x] [ ] :smiley: this is a complete item :smiley:;
- [ ] []this is an incomplete item [test link](#) :fa-star: @pandao;
- [ ] [ ]this is an incomplete item :fa-star: :fa-gear:;
    - [ ] :smiley: this is an incomplete item [test link](#) :fa-star: :fa-gear:;
    - [ ] :smiley: this is  :fa-star: :fa-gear: an incomplete item [test link](#);

#### 反斜杠 Escape

\\*literal asterisks\\*

### 科学公式 TeX(KaTeX)

$$E=mc^2$$

行内的公式$$E=mc^2$$行内的公式，行内的$$E=mc^2$$公式。

$$\\(\\sqrt{3x-1}+(1+x)^2\\)$$

$$\\sin(\\alpha)^{\\theta}=\\sum_{i=0}^{n}(x^i + \\cos(f))$$

多行公式：

\`\`\`math
\\displaystyle
\\left( \\sum\\_{k=1}^n a\\_k b\\_k \\right)^2
\\leq
\\left( \\sum\\_{k=1}^n a\\_k^2 \\right)
\\left( \\sum\\_{k=1}^n b\\_k^2 \\right)
\`\`\`

\`\`\`katex
\\displaystyle
    \\frac{1}{
        \\Bigl(\\sqrt{\\phi \\sqrt{5}}-\\phi\\Bigr) e^{
        \\frac25 \\pi}} = 1+\\frac{e^{-2\\pi}} {1+\\frac{e^{-4\\pi}} {
        1+\\frac{e^{-6\\pi}}
        {1+\\frac{e^{-8\\pi}}
         {1+\\cdots} }
        }
    }
\`\`\`

\`\`\`latex
f(x) = \\int_{-\\infty}^\\infty
    \\hat f(\\xi)\\,e^{2 \\pi i \\xi x}
    \\,d\\xi
\`\`\`

### 绘制流程图 Flowchart

\`\`\`flow
st=>start: 用户登陆
op=>operation: 登陆操作
cond=>condition: 登陆成功 Yes or No?
e=>end: 进入后台

st->op->cond
cond(yes)->e
cond(no)->op
\`\`\`

### 绘制序列图 Sequence Diagram

\`\`\`seq
Andrew->China: Says Hello
Note right of China: China thinks\\nabout it
China-->Andrew: How are you?
Andrew->>China: I am good thanks!
\`\`\`

### End`,
      isCollection: 0,
      accusation: true,
      flag: false,
      id: 'preview',
      img: './static/bg/nodata.png',
      article: {
        id: 1,
        title: '第一天',
        isExcellentArticle: 1,
        userId: 123,
        avatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/oJc2IiaoibeUm3HGMyHJ87JdLYwhvHqqcf2dETPwibotxaWGBE0vibrB8ibiazLiapBZClEHPBu3MCg7eXEicVDclFmI1A/132',
        nickname: '花开富贵',
        vipLevel: 'vip',
        categoryName: '教程',
        view: 12222,
        content: '',
        gmtModified: '2022/02/20 00:03',
        gmtCreate: '2022/02/20 00:03'
      },
      current: 0,
      limit: 20,
      reviewFlag: 1,
      labelList: [
        {
          labelName: 'java'
        },
        {
          labelName: 'vue'
        },
      ],
      total: 100,
      commentList: [
        {
          id: 1,
          userId: 2,
          userAvatar: './static/avatar/1.jpg',
          userNickname: '往事随风',
          content: '666',
          userVipLeveln: 'vip',
          gmtCreate: '2022-01-16 18:52:44',
          childList: [
            {
              id: 3,
              userId: 4,
              userAvatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJS118lQTRSw9pWrKYX3LlRXtDjaJkM48oS2wZ9N82iaPoJicKowzIYDF2q2drtwWbVC6jatrQQzEJg/132',
              userNickname: '过往云烟',
              content: '777',
              userVipLevel: 'svip',
              replyUserId: 5,
              replyUserNickname: '往事随风',
              gmtCreate: '2022-01-16 18:52:44'
            },
            {
              id: 8,
              userId: 6,
              userAvatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJS118lQTRSw9pWrKYX3LlRXtDjaJkM48oS2wZ9N82iaPoJicKowzIYDF2q2drtwWbVC6jatrQQzEJg/132',
              userNickname: '过往云烟',
              content: '777',
              userVipLevel: 'svip',
              replyUserId: 7,
              replyUserNickname: '往事随风',
              gmtCreate: '2022-01-16 18:52:44'
            },
            {
              id: 9,
              userId: 10,
              userAvatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJS118lQTRSw9pWrKYX3LlRXtDjaJkM48oS2wZ9N82iaPoJicKowzIYDF2q2drtwWbVC6jatrQQzEJg/132',
              userNickname: '花开富贵',
              content: '777',
              userVipLevel: 'svip',
              replyUserId: 11,
              replyUserNickname: '往事随风',
              gmtCreate: '2022-01-16 18:52:44'
            }
          ]
        },
        {
          id: 12,
          userId: 13,
          userAvatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJS118lQTRSw9pWrKYX3LlRXtDjaJkM48oS2wZ9N82iaPoJicKowzIYDF2q2drtwWbVC6jatrQQzEJg/132',
          userNickname: '往事随风',
          content: '666',
          userVipLeveln: 'vip',
          gmtCreate: '2022-01-16 18:52:44',
          childList: [
            {
              id: 14,
              userId: 15,
              userAvatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJS118lQTRSw9pWrKYX3LlRXtDjaJkM48oS2wZ9N82iaPoJicKowzIYDF2q2drtwWbVC6jatrQQzEJg/132',
              userNickname: '过往云烟',
              content: '777',
              userVipLevel: 'svip',
              replyUserId: 16,
              replyUserNickname: '往事随风',
              gmtCreate: '2022-01-16 18:52:44'
            },
            {
              id: 17,
              userId: 18,
              userAvatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJS118lQTRSw9pWrKYX3LlRXtDjaJkM48oS2wZ9N82iaPoJicKowzIYDF2q2drtwWbVC6jatrQQzEJg/132',
              userNickname: '过往云烟',
              content: '777',
              userVipLevel: 'svip',
              replyUserId: 19,
              replyUserNickname: '往事随风',
              gmtCreate: '2022-01-16 18:52:44'
            },
            {
              id: 20,
              userId: 21,
              userAvatar: 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJS118lQTRSw9pWrKYX3LlRXtDjaJkM48oS2wZ9N82iaPoJicKowzIYDF2q2drtwWbVC6jatrQQzEJg/132',
              userNickname: '花开富贵',
              content: '777',
              userVipLevel: 'svip',
              replyUserId: 22,
              replyUserNickname: '往事随风',
              gmtCreate: '2022-01-16 18:52:44'
            }
          ]
        },
      ],
      reviewTotal: 1000,
    }
  },
  methods: {
    createEditor,
    showAccusation() {
      this.accusation = false
    },
    cancelBtn() {
      this.accusation = true
    },
    submitBtn() {
      this.accusation = true
      if (this.reviewFlag == 1) {
        alert('是一级标题')
      } else if (this.reviewFlag == 2) {
        alert('是二级标题')
      }
    },
    replayPreview(e, flag) {
      if (flag == 1) {
        this.firstReview()
      } else if (flag == 2) {
        this.secondReview()
      }
      let opid = e.target.dataset.opid
      // 获取回复人的信息
      let ruid = e.target.dataset.ruid
      let nickname = e.target.dataset.nickname
      let avatar = e.target.dataset.avatar;
      // $("#submit-comment").data({
      //   "pid": opid,
      //   "nickname": nickname,
      //   "avatar": avatar,
      //   "ruid": ruid,
      // });


      $(e.target).parents(".comment-author").append($("#respond-post"));
      // 取消回复
      $("#cancel-comment-reply-link").show().off("click").on("click", function () {
        $('#submit-comment')
          .removeData("pid")
          .removeData("nickname")
          .removeData("avatar")
          .removeData("ruid");
        $("#commentbox-post").append($("#respond-post"))
        $("#cancel-comment-reply-link").hide()
      })
    },
    deletePreview(commentId) {
      layer.confirm('你确定删除吗?', {
        title: '提示',
        btn: ['点击删除', '放弃删除'],
      }, function (index) {
        layer.close(index); //如果设定了yes回调，需进行手工关闭
      });
    },
    mkImageShow,
    loadToc,
    backToTop,
    easeInOutQuad,
    firstReview() {
      let content = this.editor.txt.html()
      alert(content)
      // bbsApi.firstReview().then(response => {
      //
      // })
    },
    secondReview() {

      let content = this.editor.txt.html()
      alert(content)
      // bbsApi.secondReview().then(response => {
      //
      // })
    },
    getArticle(articleId) {
      bbsApi.getArticle(articleId).then(response => {
        this.markdownValue = response.data.data.article.content
        this.isCollection = response.data.data.isCollection
        this.article = response.data.data.article
        this.labelList = response.data.data.labelList
      })
    },
    findReview(articleId) {
      this.current += 1
      bbsApi.findReview(articleId).then(response => {
        this.commentList = response.data.data.commentList
      })
    },
  },
  mounted() {
    this.createEditor()
  },
  created() {
    setTimeout(this.mkImageShow, this.time);
    if (window.name == 'isReload') {
      this.backToTop('slide_bottom')
    } else {
      window.name = 'isReload'
    }
    this.getArticle(this.$route.params.bbsId)
    this.findReview(this.$route.params.bbsId)

  }
}
</script>

<style scoped>
.layui-container {
  max-width: 1200px;
  width: 1170px;
  padding: 28px;
}

.title-article h1.title {
  font-size: 28px;
  font-weight: 600;
  color: #34495e;
  padding: 0 0 10px;
  width: 82%;
  line-height: 32px;
  word-break: break-all;
}

.title-article h1 {
  font-size: 16px;
  font-weight: 600;
  color: #34495e;
  margin-top: 5px;
}

.tp2 {
  top: 2px !important;
}

.pr {
  position: relative;
}

.title-article .title-msg {
  margin-bottom: 0px;
  font-size: 12px;
  color: #999;
}

.title-article .title-msg span {
  margin-right: 3px;
}

.title-article .title-msg span.c999, .title-article .title-msg span a.c999 {
  color: #999999 !important;
}

.ksd-avatar {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  vertical-align: baseline;
  top: 7px;
  position: relative;
}

img {
  max-width: 100%;
  height: auto;
  vertical-align: middle;
  border-style: none;

}

.mr-1, .mx-1 {
  margin-right: .25rem !important;
}

.svipicon {
  color: #ff503f;
  position: relative;
  top: -1px;
  background: #f9d681;
  padding: 0 2px;
  border-radius: 12px;
  top: -1px;
}

a {
  text-decoration: none;
}

.tp1 {
  top: 1px !important;
}

.title-article .title-msg a.ksd-tiff {
  position: absolute;
  top: 35px;
  right: 25px;
  color: #4CAF50;
  font-weight: bold;
}

.title-article .title-msg a {
  color: #999;
}

.title-article .title-msg a.ksd-tiff2 {
  position: absolute;
  top: 40px;
  right: 66px;
  color: #ff6700 !important;
  font-weight: bold;
  font-size: 14px;
}

.pr-1, .px-1 {
  padding-right: .25rem !important;
}

.title-article .title-msg span {
  margin-right: 3px;
}

.title-article .title-msg span {
  margin-right: 3px;
}

.pl-4, .px-4 {
  padding-left: 1.5rem !important;
}

.fz24 {
  font-size: 24px !important;
}

.layui-container .main {
  box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
  margin: 10px auto;
  padding: 20px;
  background: #fff;
}

/*评论*/
.comment-text h3 {
  font-size: 16px;
  text-align: left;
  color: black;

}

.pinglun {
  margin-bottom: 10px;
}

.pinglun li {
  margin-bottom: 10px;
  padding: 10px;
  background: #eff3f5;
}

.animated {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}

.fadeInUpBig {
  -webkit-animation-name: fadeInUpBig;
  animation-name: fadeInUpBig;
}

.pinglun .pl-dan {
  border-radius: 4px;
  padding: 6px;
}

.pinglun .t-p {
  float: left;
  position: relative;
  top: -3px;
}

.position-relative {
  position: relative !important;
}

.pinglun .t-p img {
  width: 50px;
  height: 50px;
  border: 4px solid rgba(210, 210, 210, 0.2);
  border-radius: 200px;
  position: relative;
  z-index: 555;
}

img {
  max-width: 100%;
  height: auto;
  vertical-align: middle;
  border-style: none;
}

.pinglun .t-u {
  margin-left: 70px;
  line-height: 22px;
  padding-bottom: 10px;
  margin-bottom: 10px;
  text-align: left;
}

.fw {
  font-weight: 600 !important;
}

a {
  text-decoration: none;
}

.layui-badge:empty {
  display: none;
}

.layui-badge {
  height: 18px;
  line-height: 18px;
}

.layui-badge, .layui-badge-dot, .layui-badge-rim {
  position: relative;
  display: inline-block;
  padding: 0 6px;
  font-size: 12px;
  text-align: center;
  background-color: #FF5722;
  color: #fff;
  border-radius: 2px;
}

.pt-1, .py-1 {
  padding-top: .25rem !important;
}

.pinglun .t-u .t-g {
  color: #999;
  font-size: 12px;
}

b, strong {
  font-weight: bolder;
}

.pinglun .t-u .t-btn a {
  background: #1ab667;
  color: #fff;
  font-size: 12px;
  border: #1ab667 1px solid;
  padding: 2px 5px;
  border-radius: 4px;
  margin-right: 10px;
}

.pinglun .t-u .t-btn a.rpl-red {
  background: #ea0d0d;
  border: 1px solid #ea0d0d;
}

.pinglun .t-u .t-btn a.rpl-red:hover {
  background: #1ab667;
  border: #1ab667 1px solid;
}

.pinglun .t-u .t-btn a .iconfont {
  font-size: 13px;
  padding-right: 3px;
}

.pinglun .t-s {
  margin-top: 10px;
  margin-bottom: 10px;
  color: #888;
  word-break: break-word;
  line-height: 20px;
}

.pinglun .t-s p {
  word-break: break-all;
}

ol ol, ol ul, ul ol, ul ul {
  margin-bottom: 0;
}

.pinglun li.comment-child {
  padding: 10px 30px 0 10px;
  background: #ffff;
  margin-left: 75px;
  margin-right: 20px;
}

.comment-children .pl-dan {
  padding-left: 25px;
}

.loadmorechild a:hover, .loadmore a:hover {
  background: #eee;
}

.loadmorechild a, .loadmore a {
  display: block;
  background: #f5f5f5;
  padding: 5px;
}

/*富文本编辑器*/
.layui-form-item {
  margin-bottom: 15px;
  clear: both;
  *zoom: 1;
}

.layui-inline {
  display: inline;
  zoom: 1;
}

.layui-btn, .layui-edge, .layui-inline, img {
  vertical-align: middle;
}

.layui-edge, .layui-header, .layui-inline, .layui-main {
  position: relative;
}

/*举报表单*/
.tipoff-box {
  position: fixed;
  top: 50%;
  left: 50%;
  margin-top: -168px;
  margin-left: -225px;
  padding: 24px 32px 32px;
  width: 450px;
  height: 336px;
  background: #fff;
  box-shadow: 0 8px 16px 0 rgba(7, 17, 27, .2);
  border-radius: 8px;
  box-sizing: border-box;
  z-index: 901;
}

.animated {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}

.tipoff-box .tipoff-top-box {
  margin-bottom: 24px;
  width: 100%;
  font-size: 16px;
  color: #07111b;
  line-height: 24px;
}

.tipoff-box .tipoff-type-box {
  width: 100%;
  height: 48px;
  overflow: hidden;
  margin-bottom: 24px;
}

.clearfix {
  *zoom: 1;
}

.tipoff-box .tipoff-type-box .item {
  width: 33.3%;
  font-size: 12px;
  color: #93999f;
  line-height: 24px;
  overflow: hidden;
  cursor: pointer;
}

.tipoff-box .tipoff-type-box .item i {
  display: inline-block;
  margin-right: 4px;
  font-size: 16px;
  line-height: 24px;
}

.tipoff-box .tipoff-type-box .item p {
  max-width: 108px;
  height: 24px;
  overflow: hidden;
}

.tipoff-box .tipoff-content {
  position: relative;
}

.tipoff-box .tipoff-content .tipoff-text {
  position: absolute;
  bottom: 12px;
  right: 12px;
  font-size: 12px;
  color: #93999f;
  line-height: 12px;
}

.tipoff-box .tipoff-btn-box {
  width: 100%;
  margin-top: 24px;
}

.tipoff-box .tipoff-content .tipoff-desc {

  padding: 12px;
  width: 386px;
  height: 88px;
  background: #fff;
  border: 1px solid #d9dde1;
  border-radius: 2px;
  box-sizing: border-box;
  font-size: 14px;
  color: #07111b;
  resize: none;

}

.tipoff-box .tipoff-btn-box .tipoff-submit-btn {
  width: 76px;
  height: 36px;
  background: #1E9FFF;
  border-radius: 2px;
  font-size: 14px;
  color: #fff;
  line-height: 36px;
  text-align: center;
  cursor: pointer;
}

.tipoff-box .tipoff-btn-box .tipoff-cancel-btn {
  margin-right: 8px;
  width: 76px;
  height: 36px;
  line-height: 36px;
  border: 1px solid #d9dde1;
  border-radius: 2px;
  font-size: 14px;
  color: #93999f;
  text-align: center;
  cursor: pointer;
}

.copy-text {
  color: #666;
  padding: 0 20px;
}

.text, .copy-text, .page-text, .comment-text, .tags-text {
  overflow: hidden;
}

.mb-4, .my-4 {
  margin-bottom: 1.5rem !important;
}

.mt-4, .my-4 {
  margin-top: 1.5rem !important;
}

.ksd-topic-tags {
  position: relative;
  top: -1px;
  background: #bababa;
  color: #fff;
  padding: 2px 10px;
  margin-right: 4px;
  border-radius: 16px;
  font-size: 12px;
  display: inline-block;
  text-overflow: ellipsis;
  white-space: normal;
  overflow: hidden;
  font-style: normal;
  vertical-align: middle;
}

.ftp2 {
  top: -2px !important;
}

.ksd-topic-tags:hover {
  background-color: #76c489;
}

.pinglun .cancel-comment-reply {
  background: #f05050;
  padding: 2px 5px;
  border-radius: 4px;
  display: inline-block;
  margin-bottom: 10px;
}

.pinglun .cancel-comment-reply a {
  color: #fff;
}

.touser_sp {
  color: #31bc31;
  padding-left: 10px;
  font-size: 14px;
  font-weight: bold;
  position: relative;
  top: -1px;
  left: -4px;
}

.touser_sp a:hover {
  color: #31bc31;
}
</style>

















