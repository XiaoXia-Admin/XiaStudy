# xiastudy

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


## 接口问题
###课程模块
查找课程相关信息，为消息模块服务 （没有参数，放得模块也有问题）
